import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '../../providers/auth_provider.dart';
import '../../theme/default_theme.dart';
import '../global/mode_selection_card.dart'; // Import your mode selection card

class AcademicsScreen extends StatefulWidget {
  const AcademicsScreen({Key? key}) : super(key: key);

  @override
  State<AcademicsScreen> createState() => _AcademicsScreenState();
}

class _AcademicsScreenState extends State<AcademicsScreen> with TickerProviderStateMixin {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  // User data
  String? userCollege;
  
  // Dropdown data
  List<String> departments = [];
  List<String> semesters = [];
  List<String> subjects = [];
  List<String> units = [];
  
  // Selected values
  String? selectedDepartment;
  String? selectedSemester;
  String? selectedSubject;
  int? expandedSubjectIndex;
  
  // Loading states
  bool isLoadingDepartments = false;
  bool isLoadingSemesters = false;
  bool isLoadingSubjects = false;
  bool isLoadingUnits = false;
  
  // Animation controllers
  late AnimationController _fadeController;
  late AnimationController _slideController;
  late Animation<double> _fadeAnimation;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _initializeAnimations();
    _loadUserData();
  }

  void _initializeAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 800),
      vsync: this,
    );
    
    _slideController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    
    _fadeAnimation = Tween<double>(
      begin: 0.0,
      end: 1.0,
    ).animate(CurvedAnimation(
      parent: _fadeController,
      curve: Curves.easeInOut,
    ));
    
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.3),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _slideController,
      curve: Curves.easeOutBack,
    ));
    
    _fadeController.forward();
    _slideController.forward();
  }

  @override
  void dispose() {
    _fadeController.dispose();
    _slideController.dispose();
    super.dispose();
  }

  Future<void> _loadUserData() async {
    try {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final userData = await authProvider.getCurrentUserData();
      
      if (userData != null && userData['college'] != null) {
        setState(() {
          userCollege = userData['college'];
        });
        await _loadDepartments();
      } else {
        _showErrorSnackBar('Unable to load user college information');
      }
    } catch (e) {
      print('Error loading user data: $e');
      _showErrorSnackBar('Error loading user data');
    }
  }

  Future<void> _loadDepartments() async {
    if (userCollege == null) return;
    
    setState(() {
      isLoadingDepartments = true;
      departments.clear();
      selectedDepartment = null;
      _clearSemesterData();
    });

    try {
      final docSnapshot = await _firestore
          .collection('colleges')
          .doc(userCollege)
          .get();

      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data.containsKey('Departments')) {
          final departmentsList = List<String>.from(data['Departments'] ?? []);
          setState(() {
            departments = departmentsList;
            isLoadingDepartments = false;
          });
        } else {
          setState(() {
            isLoadingDepartments = false;
          });
          _showErrorSnackBar('No departments found for your college');
        }
      } else {
        setState(() {
          isLoadingDepartments = false;
        });
        _showErrorSnackBar('College data not found');
      }
    } catch (e) {
      setState(() {
        isLoadingDepartments = false;
      });
      print('Error loading departments: $e');
      _showErrorSnackBar('Error loading departments');
    }
  }

  Future<void> _loadSemesters(String department) async {
    setState(() {
      isLoadingSemesters = true;
      semesters.clear();
      selectedSemester = null;
      _clearSubjectData();
    });

    try {
      final docSnapshot = await _firestore
          .collection('colleges')
          .doc(userCollege)
          .collection('Departments')
          .doc(department)
          .get();

      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data.containsKey('semesters')) {
          final semestersList = List<String>.from(data['semesters'] ?? []);
          setState(() {
            semesters = semestersList;
            isLoadingSemesters = false;
          });
        } else {
          setState(() {
            isLoadingSemesters = false;
          });
          _showErrorSnackBar('No semesters found for this department');
        }
      } else {
        setState(() {
          isLoadingSemesters = false;
        });
        _showErrorSnackBar('Department data not found');
      }
    } catch (e) {
      setState(() {
        isLoadingSemesters = false;
      });
      print('Error loading semesters: $e');
      _showErrorSnackBar('Error loading semesters');
    }
  }

  Future<void> _loadSubjects(String department, String semester) async {
    setState(() {
      isLoadingSubjects = true;
      subjects.clear();
      selectedSubject = null;
      expandedSubjectIndex = null;
    });

    try {
      final docSnapshot = await _firestore
          .collection('colleges')
          .doc(userCollege)
          .collection('Departments')
          .doc(department)
          .collection('Semesters')
          .doc(semester)
          .get();

      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data.containsKey('subjectList')) {
          final subjectsList = List<String>.from(data['subjectList'] ?? []);
          setState(() {
            subjects = subjectsList;
            isLoadingSubjects = false;
          });
        } else {
          setState(() {
            isLoadingSubjects = false;
          });
          _showErrorSnackBar('No subjects found for this semester');
        }
      } else {
        setState(() {
          isLoadingSubjects = false;
        });
        _showErrorSnackBar('Semester data not found');
      }
    } catch (e) {
      setState(() {
        isLoadingSubjects = false;
      });
      print('Error loading subjects: $e');
      _showErrorSnackBar('Error loading subjects');
    }
  }

  Future<void> _loadUnits(String subject, int subjectIndex) async {
    setState(() {
      isLoadingUnits = true;
      units.clear();
    });

    try {
      final docSnapshot = await _firestore
          .collection('colleges')
          .doc(userCollege)
          .collection('Departments')
          .doc(selectedDepartment)
          .collection('Semesters')
          .doc(selectedSemester)
          .collection(subject)
          .doc('Units')
          .get();

      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null && data.containsKey('Units')) {
          final unitsList = List<String>.from(data['Units'] ?? []);
          setState(() {
            units = unitsList;
            expandedSubjectIndex = subjectIndex;
            isLoadingUnits = false;
          });
        } else {
          setState(() {
            isLoadingUnits = false;
          });
          _showErrorSnackBar('No units found for this subject');
        }
      } else {
        setState(() {
          isLoadingUnits = false;
        });
        _showErrorSnackBar('Subject data not found');
      }
    } catch (e) {
      setState(() {
        isLoadingUnits = false;
      });
      print('Error loading units: $e');
      _showErrorSnackBar('Error loading units');
    }
  }

  void _clearSemesterData() {
    semesters.clear();
    selectedSemester = null;
    _clearSubjectData();
  }

  void _clearSubjectData() {
    subjects.clear();
    selectedSubject = null;
    expandedSubjectIndex = null;
    units.clear();
  }

  void _showErrorSnackBar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: Colors.red,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  void _onUnitSelected(String unit) {
    // Show mode selection bottom sheet
    ModeSelectionBottomSheet.show(
      context: context,
      topicName: selectedSubject ?? 'Subject',
      subcategoryName: unit,
      onPracticeModeSelected: () {
        // Handle practice mode selection
        print('Practice mode selected for: $selectedSubject - $unit');
        // Navigate to practice screen
      },
      onTestModeSelected: () {
        // Handle test mode selection
        print('Test mode selected for: $selectedSubject - $unit');
        // Navigate to test screen
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey.shade50,
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: SlideTransition(
            position: _slideAnimation,
            child: CustomScrollView(
              physics: const BouncingScrollPhysics(),
              slivers: [
                // App Bar
                _buildAppBar(),
                
                // Content
                SliverPadding(
                  padding: EdgeInsets.all(20.w),
                  sliver: SliverList(
                    delegate: SliverChildListDelegate([
                      // College Info Card
                      _buildCollegeInfoCard(),
                      
                      SizedBox(height: 24.h),
                      
                      // Department Selection
                      _buildDropdownSection(
                        title: 'Select Department',
                        value: selectedDepartment,
                        items: departments,
                        isLoading: isLoadingDepartments,
                        onChanged: (String? value) {
                          setState(() {
                            selectedDepartment = value;
                            _clearSemesterData();
                          });
                          if (value != null) {
                            _loadSemesters(value);
                          }
                        },
                        icon: Icons.business,
                      ),
                      
                      if (selectedDepartment != null) ...[
                        SizedBox(height: 20.h),
                        
                        // Semester Selection
                        _buildDropdownSection(
                          title: 'Select Semester',
                          value: selectedSemester,
                          items: semesters,
                          isLoading: isLoadingSemesters,
                          onChanged: (String? value) {
                            setState(() {
                              selectedSemester = value;
                              _clearSubjectData();
                            });
                            if (value != null && selectedDepartment != null) {
                              _loadSubjects(selectedDepartment!, value);
                            }
                          },
                          icon: Icons.calendar_today,
                        ),
                      ],
                      
                      if (selectedSemester != null && subjects.isNotEmpty) ...[
                        SizedBox(height: 24.h),
                        
                        // Subjects Section
                        _buildSubjectsSection(),
                      ],
                    ]),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildAppBar() {
    return SliverAppBar(
      expandedHeight: 120.h,
      floating: true,
      pinned: false,
      backgroundColor: AppTheme.primaryColor,
      flexibleSpace: FlexibleSpaceBar(
        title: Text(
          'Academics',
          style: GoogleFonts.poppins(
            fontSize: 24.sp,
            fontWeight: FontWeight.bold,
            color: Colors.white,
          ),
        ),
        titlePadding: EdgeInsets.only(left: 20.w, bottom: 16.h),
        background: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                AppTheme.primaryColor,
                AppTheme.primaryColor.withOpacity(0.8),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildCollegeInfoCard() {
    return Container(
      padding: EdgeInsets.all(20.w),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          colors: [
            AppTheme.secondaryColor.withOpacity(0.1),
            Colors.white,
          ],
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: AppTheme.secondaryColor.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Row(
        children: [
          Container(
            padding: EdgeInsets.all(12.w),
            decoration: BoxDecoration(
              color: AppTheme.secondaryColor.withOpacity(0.1),
              borderRadius: BorderRadius.circular(12.r),
            ),
            child: Icon(
              Icons.school,
              color: AppTheme.secondaryColor,
              size: 24.sp,
            ),
          ),
          SizedBox(width: 16.w),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Your College',
                  style: GoogleFonts.poppins(
                    fontSize: 12.sp,
                    color: Colors.grey.shade600,
                    fontWeight: FontWeight.w500,
                  ),
                ),
                SizedBox(height: 4.h),
                Text(
                  userCollege ?? 'Loading...',
                  style: GoogleFonts.poppins(
                    fontSize: 16.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryColor,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildDropdownSection({
    required String title,
    required String? value,
    required List<String> items,
    required bool isLoading,
    required Function(String?) onChanged,
    required IconData icon,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          title,
          style: GoogleFonts.poppins(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.primaryColor,
          ),
        ),
        SizedBox(height: 12.h),
        Container(
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(12.r),
            border: Border.all(
              color: AppTheme.secondaryColor.withOpacity(0.2),
              width: 1,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.05),
                blurRadius: 8,
                offset: const Offset(0, 2),
              ),
            ],
          ),
          child: isLoading
              ? Container(
                  padding: EdgeInsets.all(16.w),
                  child: Row(
                    children: [
                      SizedBox(
                        width: 20.w,
                        height: 20.w,
                        child: CircularProgressIndicator(
                          strokeWidth: 2,
                          valueColor: AlwaysStoppedAnimation<Color>(
                            AppTheme.secondaryColor,
                          ),
                        ),
                      ),
                      SizedBox(width: 12.w),
                      Text(
                        'Loading...',
                        style: GoogleFonts.poppins(
                          fontSize: 14.sp,
                          color: Colors.grey.shade600,
                        ),
                      ),
                    ],
                  ),
                )
              : DropdownButtonFormField<String>(
                  value: value,
                  decoration: InputDecoration(
                    contentPadding: EdgeInsets.symmetric(
                      horizontal: 16.w,
                      vertical: 16.h,
                    ),
                    border: InputBorder.none,
                    prefixIcon: Icon(
                      icon,
                      color: AppTheme.secondaryColor,
                      size: 20.sp,
                    ),
                  ),
                  hint: Text(
                    'Choose ${title.toLowerCase()}',
                    style: GoogleFonts.poppins(
                      fontSize: 14.sp,
                      color: Colors.grey.shade500,
                    ),
                  ),
                  items: items.map((String item) {
                    return DropdownMenuItem<String>(
                      value: item,
                      child: Text(
                        item,
                        style: GoogleFonts.poppins(
                          fontSize: 14.sp,
                          color: AppTheme.primaryColor,
                        ),
                      ),
                    );
                  }).toList(),
                  onChanged: onChanged,
                  dropdownColor: Colors.white,
                  icon: Icon(
                    Icons.keyboard_arrow_down,
                    color: AppTheme.secondaryColor,
                  ),
                ),
        ),
      ],
    );
  }

  Widget _buildSubjectsSection() {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Subjects',
          style: GoogleFonts.poppins(
            fontSize: 16.sp,
            fontWeight: FontWeight.w600,
            color: AppTheme.primaryColor,
          ),
        ),
        SizedBox(height: 12.h),
        
        if (isLoadingSubjects)
          _buildLoadingCard()
        else
          ...subjects.asMap().entries.map((entry) {
            final index = entry.key;
            final subject = entry.value;
            return _buildSubjectCard(subject, index);
          }).toList(),
      ],
    );
  }

  Widget _buildLoadingCard() {
    return Container(
      padding: EdgeInsets.all(20.w),
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: AppTheme.secondaryColor.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Row(
        children: [
          SizedBox(
            width: 20.w,
            height: 20.w,
            child: CircularProgressIndicator(
              strokeWidth: 2,
              valueColor: AlwaysStoppedAnimation<Color>(
                AppTheme.secondaryColor,
              ),
            ),
          ),
          SizedBox(width: 12.w),
          Text(
            'Loading subjects...',
            style: GoogleFonts.poppins(
              fontSize: 14.sp,
              color: Colors.grey.shade600,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSubjectCard(String subject, int index) {
    final isExpanded = expandedSubjectIndex == index;
    
    return Container(
      margin: EdgeInsets.only(bottom: 12.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(12.r),
        border: Border.all(
          color: isExpanded 
              ? AppTheme.secondaryColor.withOpacity(0.4)
              : AppTheme.secondaryColor.withOpacity(0.2),
          width: isExpanded ? 2 : 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: isExpanded ? 12 : 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Subject Header
          InkWell(
            borderRadius: BorderRadius.circular(12.r),
            onTap: () {
              if (isExpanded) {
                setState(() {
                  expandedSubjectIndex = null;
                  units.clear();
                });
              } else {
                _loadUnits(subject, index);
              }
            },
            child: Padding(
              padding: EdgeInsets.all(16.w),
              child: Row(
                children: [
                  Container(
                    padding: EdgeInsets.all(8.w),
                    decoration: BoxDecoration(
                      color: AppTheme.secondaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Icon(
                      Icons.book,
                      color: AppTheme.secondaryColor,
                      size: 20.sp,
                    ),
                  ),
                  SizedBox(width: 12.w),
                  Expanded(
                    child: Text(
                      subject,
                      style: GoogleFonts.poppins(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w500,
                        color: AppTheme.primaryColor,
                      ),
                    ),
                  ),
                  if (isLoadingUnits && expandedSubjectIndex == index)
                    SizedBox(
                      width: 16.w,
                      height: 16.w,
                      child: CircularProgressIndicator(
                        strokeWidth: 2,
                        valueColor: AlwaysStoppedAnimation<Color>(
                          AppTheme.secondaryColor,
                        ),
                      ),
                    )
                  else
                    Icon(
                      isExpanded 
                          ? Icons.keyboard_arrow_up
                          : Icons.keyboard_arrow_down,
                      color: AppTheme.secondaryColor,
                      size: 20.sp,
                    ),
                ],
              ),
            ),
          ),
          
          // Units List
          if (isExpanded && units.isNotEmpty)
            Container(
              padding: EdgeInsets.fromLTRB(16.w, 0, 16.w, 16.w),
              child: Column(
                children: [
                  Divider(
                    color: AppTheme.secondaryColor.withOpacity(0.2),
                    height: 1,
                  ),
                  SizedBox(height: 12.h),
                  ...units.map((unit) => _buildUnitItem(unit)).toList(),
                ],
              ),
            ),
        ],
      ),
    );
  }

  Widget _buildUnitItem(String unit) {
    return Container(
      margin: EdgeInsets.only(bottom: 8.h),
      child: InkWell(
        borderRadius: BorderRadius.circular(8.r),
        onTap: () => _onUnitSelected(unit),
        child: Container(
          padding: EdgeInsets.all(12.w),
          decoration: BoxDecoration(
            color: AppTheme.secondaryColor.withOpacity(0.05),
            borderRadius: BorderRadius.circular(8.r),
            border: Border.all(
              color: AppTheme.secondaryColor.withOpacity(0.1),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Icon(
                Icons.play_circle_outline,
                color: AppTheme.secondaryColor,
                size: 18.sp,
              ),
              SizedBox(width: 8.w),
              Expanded(
                child: Text(
                  unit,
                  style: GoogleFonts.poppins(
                    fontSize: 13.sp,
                    color: AppTheme.primaryColor,
                    fontWeight: FontWeight.w400,
                  ),
                ),
              ),
              Icon(
                Icons.arrow_forward_ios,
                color: AppTheme.secondaryColor,
                size: 14.sp,
              ),
            ],
          ),
        ),
      ),
    );
  }
}