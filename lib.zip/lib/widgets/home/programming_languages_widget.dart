import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:provider/provider.dart';
import '../../providers/progress_provider.dart';
import '../../screens/home/listtopics_screen.dart';

class ProgrammingLanguagesWidget extends StatefulWidget {
  const ProgrammingLanguagesWidget({Key? key}) : super(key: key);

  @override
  State<ProgrammingLanguagesWidget> createState() => _ProgrammingLanguagesWidgetState();
}

class _ProgrammingLanguagesWidgetState extends State<ProgrammingLanguagesWidget> {
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  List<String> categoryTitles = [];
  Map<String, List<Map<String, dynamic>>> categoryItems = {};
  Map<String, String> displayTitles = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAllData();
  }

  Future<void> _loadAllData() async {
    await _loadCategoryTitles();
    await _loadDisplayTitles();
    await _loadAllCategoryItems();
    
    if (mounted) {
      setState(() {
        isLoading = false;
      });
    }
  }

  Future<void> _loadCategoryTitles() async {
    try {
      final titlesDoc = await _firestore.doc('/prep/Title').get();
      
      if (titlesDoc.exists && titlesDoc.data() != null) {
        final data = titlesDoc.data()!;
        
        if (data.containsKey('Title') && data['Title'] is List) {
          final List<dynamic> titles = data['Title'];
          
          setState(() {
            categoryTitles = List<String>.from(titles);
          });
          
          print('Loaded category titles: $categoryTitles');
        }
      }
    } catch (e) {
      print('Error loading category titles: $e');
    }
  }

  Future<void> _loadDisplayTitles() async {
    try {
      final displayDoc = await _firestore.doc('/prep/TitleDisplay').get();
      
      if (displayDoc.exists && displayDoc.data() != null) {
        final data = displayDoc.data()!;
        
        // Create a map of category IDs to display titles
        Map<String, String> titles = {};
        
        // For each category title, check if there's a display name
        for (String categoryId in categoryTitles) {
          if (data.containsKey(categoryId) && data[categoryId] is String) {
            titles[categoryId] = data[categoryId];
          } else {
            // Default to the category ID if no display name is found
            titles[categoryId] = categoryId;
          }
        }
        
        setState(() {
          displayTitles = titles;
        });
        
        print('Loaded display titles: $displayTitles');
      }
    } catch (e) {
      print('Error loading display titles: $e');
    }
  }

  Future<void> _loadAllCategoryItems() async {
    // For each category title, load its items
    for (String categoryId in categoryTitles) {
      await _loadCategoryItems(categoryId);
    }
  }

  Future<void> _loadCategoryItems(String categoryId) async {
    try {
      final categoryItemsRef = _firestore.doc('/prep/Title/$categoryId/$categoryId');
      final docSnapshot = await categoryItemsRef.get();
      
      if (docSnapshot.exists && docSnapshot.data() != null) {
        final data = docSnapshot.data()!;
        
        // Debug the document data
        print('$categoryId document data: $data');
        
        // Check for the field with same name as categoryId
        if (data.containsKey(categoryId) && data[categoryId] is List) {
          final List<dynamic> rawItems = data[categoryId];
          print('Raw items for $categoryId: $rawItems');
          
          // Convert items to Map<String, dynamic> with defaults for missing fields
          final List<Map<String, dynamic>> formattedItems = [];
          
          for (var item in rawItems) {
            if (item is Map) {
              final Map<String, dynamic> formattedItem = Map<String, dynamic>.from(item as Map);
              
              // Set default values for icon and color if not present
              if (!formattedItem.containsKey('icon')) {
                formattedItem['icon'] = _getDefaultIconForCategory(categoryId);
              }
              
              if (!formattedItem.containsKey('color')) {
                formattedItem['color'] = _getDefaultColorForCategory(categoryId);
              }
              
              formattedItems.add(formattedItem);
            } else if (item is String) {
              // If item is just a string, create a map with defaults
              formattedItems.add({
                'name': item,
                'icon': _getDefaultIconForCategory(categoryId),
                'color': _getDefaultColorForCategory(categoryId)
              });
            }
          }
          
          print('Formatted items for $categoryId: $formattedItems');
          
          if (mounted) {
            setState(() {
              categoryItems[categoryId] = formattedItems;
            });
          }
        }
      }
    } catch (e) {
      print('Error loading items for $categoryId: $e');
    }
  }
  
  // Get default icon for a category
  dynamic _getDefaultIconForCategory(String categoryId) {
    switch (categoryId) {
      case 'Programming Language':
        return 'assets/icons/code_icon.png';
      case 'Web Development':
        return Icons.web;
      case 'App Development':
        return Icons.smartphone;
      case 'Database':
        return Icons.storage;
      case 'UI/UX':
        return Icons.design_services;
      case 'Cloud Computing':
        return Icons.cloud;
      case 'DevOps':
        return Icons.integration_instructions;
      case 'Machine Learning':
        return Icons.psychology;
      default:
        return Icons.code;
    }
  }
  
  // Get default color for a category
  Color _getDefaultColorForCategory(String categoryId) {
    switch (categoryId) {
      case 'Programming Language':
        return const Color(0xFF366D9C);
      case 'Web Development':
        return const Color(0xFF2A6099);
      case 'App Development':
        return const Color(0xFF388E3C);
      case 'Database':
        return const Color(0xFF7B1FA2);
      case 'Cloud Computing':
        return const Color(0xFF0288D1);
      default:
        return const Color(0xFF366D9C);
    }
  }

  // Navigate to ListTopicsScreen with specific topic expanded
  void _navigateToListTopics(BuildContext context, String categoryId, String? expandedTopic) {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ListTopicsScreen(
          categoryName: displayTitles[categoryId] ?? categoryId,
          categoryId: categoryId,
          initialExpandedTopic: expandedTopic,
        ),
      ),
    );
  }

  // Get language background gradient
  List<Color> _getLanguageBackgroundGradient(String language) {
    // Default gradient (fallback)
    List<Color> gradientColors = [
      const Color(0xFFEDE5F4), // Deeper purple at the bottom
      const Color(0xFFF9F5FF), // Lighter purple at the top
    ];
    
    // Define specific gradients for programming languages (bottom to top)
    switch (language.toLowerCase()) {
      case 'swift':
        gradientColors = [
          const Color(0xFFFFE0D5),
          const Color(0xFFFFF5F2),
        ];
        break;
      case 'dart':
        gradientColors = [
          const Color(0xFFD6E8FF),
          const Color(0xFFF2F7FF),
        ];
        break;
      case 'python':
        gradientColors = [
          const Color(0xFFD9EBFF),
          const Color(0xFFF5F9FF),
        ];
        break;
      case 'javascript':
        gradientColors = [
          const Color(0xFFFFF6D6),
          const Color(0xFFFFFDF5),
        ];
        break;
      case 'java':
        gradientColors = [
          const Color(0xFFFFDDDD),
          const Color(0xFFFFF5F5),
        ];
        break;
      case 'c#':
      case 'csharp':
        gradientColors = [
          const Color(0xFFEADDFF),
          const Color(0xFFF9F5FF),
        ];
        break;
      case 'c++':
      case 'cpp':
        gradientColors = [
          const Color(0xFFD6EBFF),
          const Color(0xFFF2F8FF),
        ];
        break;
      case 'ruby':
        gradientColors = [
          const Color(0xFFFFDDE3),
          const Color(0xFFFFF5F7),
        ];
        break;
      case 'go':
      case 'golang':
        gradientColors = [
          const Color(0xFFD6F5FA),
          const Color(0xFFF2FDFF),
        ];
        break;
      case 'kotlin':
        gradientColors = [
          const Color(0xFFE4DDFF),
          const Color(0xFFF7F5FF),
        ];
        break;
      case 'typescript':
        gradientColors = [
          const Color(0xFFD6E5F9),
          const Color(0xFFF2F8FF),
        ];
        break;
      case 'php':
        gradientColors = [
          const Color(0xFFDDE1FF),
          const Color(0xFFF5F7FF),
        ];
        break;
      case 'r':
        gradientColors = [
          const Color(0xFFDEEBFF),
          const Color(0xFFF7FAFF),
        ];
        break;
        
      // Web Development Technologies
      case 'html':
      case 'html5':
        gradientColors = [
          const Color(0xFFFFE8D9),
          const Color(0xFFFFF9F5),
        ];
        break;
      case 'css':
      case 'css3':
        gradientColors = [
          const Color(0xFFD9F0FF),
          const Color(0xFFF5FAFF),
        ];
        break;
      case 'react':
      case 'react.js':
        gradientColors = [
          const Color(0xFFD9F8FF),
          const Color(0xFFF4FDFF),
        ];
        break;
      case 'angular':
        gradientColors = [
          const Color(0xFFFFDADA),
          const Color(0xFFFFF5F5),
        ];
        break;
      case 'vue':
      case 'vue.js':
        gradientColors = [
          const Color(0xFFDFFCE9),
          const Color(0xFFF6FFF9),
        ];
        break;
      case 'node':
      case 'node.js':
        gradientColors = [
          const Color(0xFFE2FFD9),
          const Color(0xFFF7FFF5),
        ];
        break;
        
      // Cloud Computing
      case 'aws':
      case 'amazon web services':
        gradientColors = [
          const Color(0xFFFFECD6),
          const Color(0xFFFFF9F0),
        ];
        break;
      case 'azure':
      case 'microsoft azure':
        gradientColors = [
          const Color(0xFFD6E5FF),
          const Color(0xFFF5F9FF),
        ];
        break;
      case 'gcp':
      case 'google cloud':
        gradientColors = [
          const Color(0xFFF5E6FF),
          const Color(0xFFFBF5FF),
        ];
        break;
      case 'docker':
        gradientColors = [
          const Color(0xFFD9F2FF),
          const Color(0xFFF5FBFF),
        ];
        break;
      case 'kubernetes':
      case 'k8s':
        gradientColors = [
          const Color(0xFFD9EAFF),
          const Color(0xFFF5F9FF),
        ];
        break;
        
      // App Development
      case 'android':
        gradientColors = [
          const Color(0xFFE5FFD9),
          const Color(0xFFF9FFF5),
        ];
        break;
      case 'ios':
        gradientColors = [
          const Color(0xFFEBEBFF),
          const Color(0xFFF7F7FF),
        ];
        break;
      case 'flutter':
        gradientColors = [
          const Color(0xFFD9EDFF),
          const Color(0xFFF5FAFF),
        ];
        break;
      case 'react native':
        gradientColors = [
          const Color(0xFFD9F8FF),
          const Color(0xFFF4FDFF),
        ];
        break;
      case 'xamarin':
        gradientColors = [
          const Color(0xFFD9E6FF),
          const Color(0xFFF5F9FF),
        ];
        break;
        
      // General Skills & Others
      case 'ui/ux':
      case 'ui':
      case 'ux':
        gradientColors = [
          const Color(0xFFFBE2FF),
          const Color(0xFFFEF7FF),
        ];
        break;
      case 'database':
      case 'sql':
        gradientColors = [
          const Color(0xFFE5E2FF),
          const Color(0xFFF9F8FF),
        ];
        break;
      case 'devops':
        gradientColors = [
          const Color(0xFFFFE2DF),
          const Color(0xFFFFF7F6),
        ];
        break;
      case 'machine learning':
      case 'ml':
      case 'ai':
        gradientColors = [
          const Color(0xFFE2F8FF),
          const Color(0xFFF7FDFF),
        ];
        break;
      case 'data science':
        gradientColors = [
          const Color(0xFFE8E2FF),
          const Color(0xFFF9F7FF),
        ];
        break;
      case 'blockchain':
        gradientColors = [
          const Color(0xFFFFEED9),
          const Color(0xFFFFFAF5),
        ];
        break;
      case 'web development':
        gradientColors = [
          const Color(0xFFD9EEFF),
          const Color(0xFFF5FAFF),
        ];
        break;
      case 'app development':
        gradientColors = [
          const Color(0xFFE0FFEC),
          const Color(0xFFF5FFF9),
        ];
        break;
      case 'cloud computing':
        gradientColors = [
          const Color(0xFFE7F0FF),
          const Color(0xFFF9FBFF),
        ];
        break;
      case 'general skills':
        gradientColors = [
          const Color(0xFFF5E8FF),
          const Color(0xFFFCF7FF),
        ];
        break;
    }
    
    return gradientColors;
  }

  // Get language icon
  Widget _getLanguageIcon(String language, Color defaultColor) {
    // Default fallback
    IconData iconData = Icons.code;
    Color iconColor = defaultColor;
    
    // Assign specific icons based on language
    switch (language.toLowerCase()) {
      case 'swift':
        return Image.asset(
          'assets/icons/swift_logo.png',
          width: 55.w,
          height: 55.h,
          errorBuilder: (context, error, stackTrace) {
            return Icon(
              Icons.sports_volleyball,
              size: 55.sp,
              color: const Color(0xFFFF6243),
            );
          },
        );
      case 'dart':
        return Image.asset(
          'assets/icons/dart_logo.png',
          width: 55.w,
          height: 55.h,
          errorBuilder: (context, error, stackTrace) {
            return Icon(
              Icons.timeline,
              size: 55.sp,
              color: const Color(0xFF42A5F5),
            );
          },
        );
      case 'java':
        return Image.asset(
          'assets/home_page/java.png',
          width: 55.w,
          height: 55.h,
          errorBuilder: (context, error, stackTrace) {
            return Icon(
              Icons.coffee,
              size: 55.sp,
              color: const Color(0xFFE76F00),
            );
          },
        );
      case 'python':
        iconData = Icons.code;
        iconColor = const Color(0xFF306998);
        break;
      case 'javascript':
        iconData = Icons.javascript;
        iconColor = const Color(0xFFF7DF1E);
        break;
      case 'c#':
      case 'csharp':
        iconData = Icons.tag;
        iconColor = const Color(0xFF9B4F96);
        break;
      case 'c++':
      case 'cpp':
        iconData = Icons.data_object;
        iconColor = const Color(0xFF00599C);
        break;
      case 'ruby':
        iconData = Icons.diamond;
        iconColor = const Color(0xFFCC342D);
        break;
      case 'go':
      case 'golang':
        iconData = Icons.pets;
        iconColor = const Color(0xFF00ADD8);
        break;
      case 'kotlin':
        iconData = Icons.hexagon;
        iconColor = const Color(0xFF7F52FF);
        break;
      case 'typescript':
        iconData = Icons.integration_instructions;
        iconColor = const Color(0xFF007ACC);
        break;
      case 'php':
        iconData = Icons.php;
        iconColor = const Color(0xFF777BB4);
        break;
      case 'r':
        iconData = Icons.bar_chart;
        iconColor = const Color(0xFF2266BB);
        break;
    }
    
    return Icon(
      iconData,
      size: 55.sp,
      color: iconColor,
    );
  }

  @override
  Widget build(BuildContext context) {
    if (isLoading) {
      return const Center(child: CircularProgressIndicator());
    }
    
    // Get progress provider for all categories
    final progressProvider = Provider.of<ProgressProvider>(context);
    
    return Column(
      children: categoryTitles.map((categoryId) {
        // Get the items for this category
        final items = categoryItems[categoryId] ?? [];
        
        // Skip if this category has no items
        if (items.isEmpty) {
          return const SizedBox();
        }
        
        // Get display title for this category (fallback to category ID if not found)
        final title = displayTitles[categoryId] ?? categoryId;
        
        // Category-specific styles - just change the section title style
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Enhanced Section Title - bigger and black text
            Padding(
              padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Text(
                    title,
                    style: TextStyle(
                      fontSize: 22.sp,
                      fontWeight: FontWeight.bold,
                      color: Colors.black87,
                    ),
                  ),
                  GestureDetector(
                    onTap: () {
                      // Navigate to list topics screen for this category
                      _navigateToListTopics(context, categoryId, null);
                    },
                    child: Text(
                      "View all",
                      style: TextStyle(
                        fontSize: 14.sp,
                        color: Color.fromRGBO(237, 85, 100, 1),
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            
            // Items in horizontal scrollable list
            Container(
              height: 162.h, // Container height: card height (142) + vertical padding (20)
              child: ListView.builder(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.only(left: 20.w, right: 8.w),
                itemCount: items.length,
                itemBuilder: (context, index) {
                  final item = items[index];
                  
                  // Handle different data formats from Firestore
                  final String name = item['name'] ?? 'Unknown';
                  
                  // Handle color data from Firestore (which might be stored differently)
                  final Color color = item['color'] is Color 
                      ? item['color'] as Color 
                      : _getDefaultColorForCategory(categoryId);
                  
                  // Create a unique ID for this topic (for progress tracking)
                  final String topicId = '${categoryId}_${name.replaceAll(' ', '_').toLowerCase()}';
                  
                  // Get progress for this topic
                  final double progress = progressProvider.getProgressForTopic(topicId);
                  
                  // Check if this topic has any progress
                  final bool hasProgress = progressProvider.hasProgress(topicId);
                  
                  // Use SizedBox to enforce exact dimensions
                  return SizedBox(
                    width: 185.w,
                    height: 142.h,
                    child: Padding(
                      padding: EdgeInsets.only(right: 12.w),
                      child: GestureDetector(
                        onTap: () {
                          // Navigate to list topics screen with this topic expanded
                          _navigateToListTopics(context, categoryId, name);
                        },
                        child: Container(
                          decoration: BoxDecoration(
                            gradient: LinearGradient(
                              colors: _getLanguageBackgroundGradient(name),
                              begin: Alignment.bottomCenter,
                              end: Alignment.topCenter,
                            ),
                            borderRadius: BorderRadius.circular(20.r),
                            border: Border.all(
                              color: const Color.fromRGBO(246, 235, 247, 1),
                              width: 1.5,
                            ),
                            boxShadow: [
                              BoxShadow(
                                color: Colors.black.withOpacity(0.06),
                                blurRadius: 10,
                                offset: const Offset(0, 2),
                              ),
                            ],
                          ),
                          child: Column(
                            mainAxisAlignment: MainAxisAlignment.center,
                            children: [
                              // Logo/icon directly on the gradient background
                              _buildItemIcon(item['icon'], color, categoryId),
                              
                              // Space between icon and text
                              SizedBox(height: 10.h),
                              
                              // Topic name
                              Text(
                                name,
                                style: TextStyle(
                                  fontSize: 16.sp,
                                  fontWeight: FontWeight.w600,
                                  color: Color(0xFF341B58),
                                ),
                                textAlign: TextAlign.center,
                                maxLines: 1,
                                overflow: TextOverflow.ellipsis,
                              ),
                              
                              // Add progress indicator if there's progress
                              if (hasProgress)
                                Padding(
                                  padding: EdgeInsets.only(top: 8.h),
                                  child: Container(
                                    width: 120.w,
                                    height: 4.h,
                                    decoration: BoxDecoration(
                                      color: Colors.white,
                                      borderRadius: BorderRadius.circular(2.r),
                                    ),
                                    child: Row(
                                      children: [
                                        Container(
                                          width: 120.w * progress,
                                          height: 4.h,
                                          decoration: BoxDecoration(
                                            color: const Color(0xFFE57896),
                                            borderRadius: BorderRadius.circular(2.r),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                            ],
                          ),
                        ),
                      ),
                    ),
                  );
                },
              ),
            ),
            
            SizedBox(height: 15.h), // Space between categories
          ],
        );
      }).toList(),
    );
  }
  
  // Get language icon
  Widget _buildItemIcon(dynamic iconData, Color color, String categoryId) {
    // Handle string path (asset image)
    if (iconData is String) {
      return Image.asset(
        iconData,
        width: 55.w,
        height: 55.h,
        errorBuilder: (context, error, stackTrace) {
          // Fallback to icon if image loading fails
          return _getLanguageIcon(categoryId, color);
        },
      );
    }
    
    // Handle IconData
    else if (iconData is IconData) {
      return Icon(
        iconData,
        size: 55.sp,
        color: _getIconColor(categoryId),
      );
    }
    
    // Default icon based on category
    return _getLanguageIcon(categoryId, color);
  }
  
  // Get appropriate icon color based on category
  Color _getIconColor(String categoryId) {
    switch (categoryId.toLowerCase()) {
      // Programming Languages
      case 'programming language':
        return const Color(0xFF5D429D);
      
      // Web Development
      case 'web development':
        return const Color(0xFF2A6099);
      
      // App Development
      case 'app development':
        return const Color(0xFF388E3C);
      
      // Cloud Computing
      case 'cloud computing':
        return const Color(0xFF0288D1);
      
      // General Skills
      case 'general skills':
        return const Color(0xFF8E24AA);
      
      // Database
      case 'database':
        return const Color(0xFF7B1FA2);
      
      // DevOps
      case 'devops':
        return const Color(0xFFE65100);
      
      // UI/UX
      case 'ui/ux':
        return const Color(0xFFEC407A);
      
      // Machine Learning
      case 'machine learning':
        return const Color(0xFF00897B);
      
      // Default
      default:
        return const Color(0xFF4A1E69);
    }
  }
}