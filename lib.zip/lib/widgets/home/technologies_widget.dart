import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'dart:math' as math;

class TechnologiesWidget extends StatefulWidget {
  final Map<String, List<Map<String, dynamic>>> categoryItems;
  final List<String> categoryTitles;

  const TechnologiesWidget({
    Key? key,
    required this.categoryItems,
    required this.categoryTitles,
  }) : super(key: key);

  @override
  State<TechnologiesWidget> createState() => _TechnologiesWidgetState();
}

class _TechnologiesWidgetState extends State<TechnologiesWidget> with TickerProviderStateMixin {
  // Animation controllers for the floating effect
  late List<AnimationController> _animationControllers;
  late List<Animation<double>> _animations;

  @override
  void initState() {
    super.initState();
    
    // Initialize animation controllers for each potential card
    _animationControllers = List.generate(8, (index) {
      // Stagger the animations with different durations
      final randomDuration = 3000 + (math.Random().nextInt(2000));
      return AnimationController(
        vsync: this,
        duration: Duration(milliseconds: randomDuration),
      )..repeat(reverse: true);
    });
    
    // Create animations with different curves
    _animations = _animationControllers.map((controller) {
      return Tween<double>(
        begin: -3.0,
        end: 3.0,
      ).animate(
        CurvedAnimation(
          parent: controller,
          curve: Curves.easeInOut,
        ),
      );
    }).toList();
  }

  @override
  void dispose() {
    // Dispose animation controllers
    for (var controller in _animationControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Create a list of technology categories, excluding Programming Language
    final List<Map<String, dynamic>> technologies = [];
    
    // Add each technology category
    for (final category in widget.categoryTitles) {
      if (category != 'Programming Language') {
        IconData icon;
        Color iconColor;
        
        // Assign specific icons and colors based on category
        switch(category) {
          case 'Web Development':
            icon = Icons.web;
            iconColor = const Color(0xFF2A6099);
            break;
          case 'App Development':
            icon = Icons.smartphone;
            iconColor = const Color(0xFF388E3C);
            break;
          case 'Database':
            icon = Icons.storage;
            iconColor = const Color(0xFF7B1FA2);
            break;
          case 'UI/UX':
            icon = Icons.design_services;
            iconColor = const Color(0xFF9C27B0);
            break;
          case 'Cloud Computing':
            icon = Icons.cloud;
            iconColor = const Color(0xFF0288D1);
            break;
          case 'DevOps':
            icon = Icons.integration_instructions;
            iconColor = const Color(0xFFE65100);
            break;
          case 'Machine Learning':
            icon = Icons.psychology;
            iconColor = const Color(0xFF00897B);
            break;
          default:
            icon = Icons.code;
            iconColor = const Color(0xFF366D9C);
        }
        
        technologies.add({
          'name': category,
          'icon': icon,
          'iconColor': iconColor
        });
      }
    }
    
    // If no technologies found in real data, use dummy data for UI testing
    if (technologies.isEmpty) {
      technologies.addAll([
        {'name': 'Web Development', 'icon': Icons.web, 'iconColor': const Color(0xFF2A6099)},
        {'name': 'DevOps', 'icon': Icons.integration_instructions, 'iconColor': const Color(0xFFE65100)},
        {'name': 'Cloud Computing', 'icon': Icons.cloud, 'iconColor': const Color(0xFF0288D1)},
        {'name': 'UI/UX Design', 'icon': Icons.design_services, 'iconColor': const Color(0xFF9C27B0)},
      ]);
    }

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Enhanced Section Title - bigger and black text
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Technologies',
                style: TextStyle(
                  fontSize: 22.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Text(
                "View all",
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Color.fromRGBO(237, 85, 100, 1),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        
        // Technology cards implementation with scrollable rows from prep.dart
        Column(
          children: [
            // First row of technologies
            Container(
              height: 70.h, // Set fixed height for the row
              margin: EdgeInsets.only(bottom: 0.2.h),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  mainAxisSize: MainAxisSize.min, // Important to prevent overflow
                  children: [
                    _buildAnimatedTechnologyCard(technologies[0], 0),
                    SizedBox(width: 10.w),
                    _buildAnimatedTechnologyCard(technologies.length > 1 ? technologies[1] : technologies[0], 1),
                  ],
                ),
              ),
            ),
            
            // Second row of technologies
            Container(
              height: 70.h, // Set fixed height for the row
              margin: EdgeInsets.only(bottom: 5.h),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                physics: const BouncingScrollPhysics(),
                padding: EdgeInsets.symmetric(horizontal: 20.w),
                child: Row(
                  mainAxisSize: MainAxisSize.min, // Important to prevent overflow
                  children: [
                    _buildAnimatedTechnologyCard(technologies.length > 2 ? technologies[2] : technologies[0], 2),
                    SizedBox(width: 10.w),
                    _buildAnimatedTechnologyCard(technologies.length > 3 ? technologies[3] : technologies.length > 1 ? technologies[1] : technologies[0], 3),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
  
  Widget _buildAnimatedTechnologyCard(Map<String, dynamic> technology, int animationIndex) {
    return AnimatedBuilder(
      animation: _animationControllers[animationIndex],
      builder: (context, child) {
        return Transform.translate(
          offset: Offset(_animations[animationIndex].value, 0), // Horizontal movement
          child: child,
        );
      },
      child: _buildDynamicTechnologyCard(technology),
    );
  }
  
  Widget _buildDynamicTechnologyCard(Map<String, dynamic> technology) {
    // Fixed card height
    final double cardHeight = 58.h;
    // Fixed icon size
    final double iconSize = 24.sp;
    
    return Container(
      height: cardHeight,
      padding: EdgeInsets.symmetric(horizontal: 12.w),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18.r),
        border: Border.all(
          color: const Color.fromRGBO(247, 237, 248, 1),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: const Color.fromRGBO(252, 247, 252, 1),
            blurRadius: 8,
            spreadRadius: 2,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      // IntrinsicWidth will make the container just wide enough for its children
      child: IntrinsicWidth(
        child: Row(
          mainAxisSize: MainAxisSize.min, // Very important to prevent overflow
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Icon(
              technology['icon'] as IconData,
              color: technology['iconColor'] as Color,
              size: iconSize,
            ),
            SizedBox(width: 8.w),
            // Use an automatically sized Text widget
            Text(
              technology['name'] as String,
              style: TextStyle(
                fontSize: 15.5.sp,
                fontWeight: FontWeight.w500,
                color: Color.fromRGBO(61, 21, 96, 1),
              ),
            ),
            // Add a small padding on the right for aesthetics
            SizedBox(width: 4.w),
          ],
        ),
      ),
    );
  }
}