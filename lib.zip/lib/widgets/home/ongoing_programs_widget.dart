import 'package:flutter/material.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';

class OngoingProgramsWidget extends StatelessWidget {
  final Map<String, List<Map<String, dynamic>>> categoryItems;

  const OngoingProgramsWidget({
    Key? key,
    required this.categoryItems,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    // These would normally be fetched from user progress data or use the provided categoryItems
    final List<Map<String, dynamic>> ongoingPrograms = [
      {'name': 'Web Development', 'progress': 0.75, 'icon': 'assets/icons/webdev_icon.png'},
      {'name': 'Python', 'progress': 0.45, 'icon': 'assets/icons/python_icon.png'},
      {'name': 'Flutter', 'progress': 0.60, 'icon': 'assets/icons/flutter_icon.png'},
    ];

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Enhanced Section Title - bigger and black text
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 20.w, vertical: 16.h),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Text(
                'Ongoing Programs',
                style: TextStyle(
                  fontSize: 22.sp,
                  fontWeight: FontWeight.bold,
                  color: Colors.black87,
                ),
              ),
              Text(
                "View all",
                style: TextStyle(
                  fontSize: 14.sp,
                  color: Color.fromRGBO(237, 85, 100, 1),
                  fontWeight: FontWeight.w500,
                ),
              ),
            ],
          ),
        ),
        
        // Using the card design from prep.dart
        Container(
          height: 162.h, // Container height: card height + vertical padding
          child: ListView.builder(
            scrollDirection: Axis.horizontal,
            physics: const BouncingScrollPhysics(),
            padding: EdgeInsets.only(left: 20.w, right: 8.w),
            itemCount: ongoingPrograms.length,
            itemBuilder: (context, index) {
              return _buildProgramCard(ongoingPrograms[index]);
            },
          ),
        ),
      ],
    );
  }
  
  Widget _buildProgramCard(Map<String, dynamic> program) {
    // Define a wider fixed size
    final double cardWidth = 180.w;
    final double cardHeight = 160.h;
    // Calculate progress percentage
    final double progressValue = program['progress'] as double;

    return Container(
      width: cardWidth,
      height: cardHeight,
      margin: EdgeInsets.only(right: 12.w),
      decoration: BoxDecoration(
        gradient: const LinearGradient(
          colors: [
            Color.fromRGBO(255, 253, 255, 1), 
            Color.fromRGBO(255, 244, 246, 1),
            Color.fromRGBO(255, 239, 243, 1),
            Color.fromRGBO(255, 233, 240, 1),
            Color.fromRGBO(255, 229, 237, 1),
          ],
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
        ),
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: const Color.fromRGBO(239, 220, 240, 1),
          width: 1.5,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Column(
        children: [
          // Main content area
          Expanded(
            child: Padding(
              padding: EdgeInsets.fromLTRB(10.w, 15.h, 10.w, 5.h),
              child: Column(
                children: [
                  // App icon centered
                  Expanded(
                    child: Center(
                      child: program['name'] == 'Web Development'
                        ? Image.asset(
                            'assets/icons/webdev_icon.png',
                            width: 60.w,
                            height: 60.h,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                Icons.web,
                                color: Color(0xFF6E7FAA),
                                size: 40.sp,
                              );
                            },
                          )
                        : program['name'] == 'Python'
                        ? Image.asset(
                            'assets/icons/python_icon.png',
                            width: 60.w,
                            height: 60.h,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                Icons.code,
                                color: Color(0xFF6E7FAA),
                                size: 40.sp,
                              );
                            },
                          )
                        : Image.asset(
                            program['icon'] as String,
                            width: 60.w,
                            height: 60.h,
                            errorBuilder: (context, error, stackTrace) {
                              return Icon(
                                Icons.code,
                                color: Color(0xFF6E7FAA),
                                size: 40.sp,
                              );
                            },
                          ),
                    ),
                  ),
                  
                  // Container with light pink background holding progress bar and percentage
                  Container(
                    width: double.infinity, // Make the container use full available width
                    margin: EdgeInsets.only(top: 20.h),
                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 1.h),
                    decoration: BoxDecoration(
                      color: const Color.fromRGBO(252, 227, 234, 1), // Light pink background
                      borderRadius: BorderRadius.circular(8.r),
                    ),
                    child: Row(
                      children: [
                        // Progress bar with white unfilled portion
                        Expanded(
                          child: Container(
                            height: 5.h, // Smaller height
                            decoration: BoxDecoration(
                              color: Colors.white, // White background for unfilled area
                              borderRadius: BorderRadius.circular(3.r),
                            ),
                            child: LayoutBuilder(
                              builder: (context, constraints) {
                                return Row(
                                  children: [
                                    Container(
                                      width: constraints.maxWidth * progressValue,
                                      decoration: BoxDecoration(
                                        color: const Color(0xFFEB5B86), // Pink filled portion
                                        borderRadius: BorderRadius.circular(3.r),
                                      ),
                                    ),
                                  ],
                                );
                              },
                            ),
                          ),
                        ),
                        
                        // Percentage text
                        SizedBox(width: 8.w),
                        Text(
                          "${(progressValue * 100).toInt()}%",
                          style: TextStyle(
                            color: Color(0xFFEB5B86),
                            fontSize: 12.sp,
                            fontWeight: FontWeight.w500,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
          
          // Program name at bottom with increased height and centered text
          Container(
            width: double.infinity,
            padding: EdgeInsets.symmetric(vertical: 16.h, horizontal: 10.w),
            margin: EdgeInsets.fromLTRB(1.w, 1.h, 1.w, 1.h),
            decoration: const BoxDecoration(
              color: Color.fromRGBO(255, 229, 237, 1),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(12),
                bottomRight: Radius.circular(12),
              ),
            ),
            child: Text(
              program['name'] as String,
              style: const TextStyle(
                color: Color(0xFF4A3960),
                fontSize: 14,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
          ),
        ],
      ),
    );
  }
}