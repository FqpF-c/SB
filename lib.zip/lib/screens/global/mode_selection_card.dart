import 'package:flutter/material.dart';
import 'dart:ui';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../../theme/default_theme.dart';
import '../../providers/auth_provider.dart';
import 'quiz_loading_screen.dart';

class ModeSelectionCard extends StatelessWidget {
  final String topicName;
  final String subcategoryName;
  final String type; // 'programming' or 'academic'
  final Map<String, dynamic> quizParams;
  final Function()? onPracticeModeSelected;
  final Function()? onTestModeSelected;
  
  const ModeSelectionCard({
    Key? key,
    required this.topicName,
    required this.subcategoryName,
    required this.type,
    required this.quizParams,
    this.onPracticeModeSelected,
    this.onTestModeSelected,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(bottom: 24.h),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.only(
          topLeft: Radius.circular(48),
          topRight: Radius.circular(48),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Handle bar at the top
          Center(
            child: Container(
              margin: EdgeInsets.only(top: 10.h, bottom: 20.h),
              width: 90.w,
              height: 6.h,
              decoration: BoxDecoration(
                color: AppTheme.secondaryColor,
                borderRadius: BorderRadius.circular(8.r),
              ),
            ),
          ),
          
          // Title and subtitle
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Select Mode',
                  style: GoogleFonts.poppins(
                    fontSize: 20.sp,
                    fontWeight: FontWeight.w600,
                    color: AppTheme.primaryColor,
                  ),
                ),
                
                SizedBox(height: 4.h),
                
                Text(
                  topicName,
                  style: GoogleFonts.poppins(
                    fontSize: 14.sp,
                    color: Colors.grey[600],
                  ),
                ),
                
                if (subcategoryName.isNotEmpty) ...[
                  Text(
                    subcategoryName,
                    style: GoogleFonts.poppins(
                      fontSize: 12.sp,
                      color: Colors.grey[500],
                    ),
                  ),
                ],
              ],
            ),
          ),
          
          SizedBox(height: 20.h),
          
          // Practice Mode Card
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: _buildModeCard(
              context: context,
              icon: Icons.fitness_center,
              title: 'Practice Mode',
              description: 'Infinite questions with immediate feedback. Perfect for learning!',
              features: [
                '10 questions per batch',
                'Infinite questions',
                'Instant feedback', 
                '2 XP per correct answer', 
                'No time limit'
              ],
              buttonText: 'Start Practice',
              backgroundColor: AppTheme.secondaryColor.withOpacity(0.05),
              onPressed: () => _startMode(context, 'practice'),
            ),
          ),
          
          SizedBox(height: 12.h),
          
          // Test Mode Card
          Padding(
            padding: EdgeInsets.symmetric(horizontal: 24.w),
            child: _buildModeCard(
              context: context,
              icon: Icons.quiz,
              title: 'Test Mode',
              description: 'Challenge yourself with 20 questions and time limit!',
              features: [
                '20 questions total',
                '2 sets of 10 questions',
                '20 minutes timer', 
                '4 XP per correct answer', 
                'Final score report'
              ],
              buttonText: 'Start Test',
              backgroundColor: Colors.white,
              onPressed: () => _startMode(context, 'test'),
            ),
          ),
        ],
      ),
    );
  }
  
  void _startMode(BuildContext context, String mode) {
    Navigator.pop(context); // Close the modal
    
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => QuizLoadingScreen(
          mode: mode,
          type: type,
          quizParams: quizParams,
          topicName: topicName,
          subtopicName: subcategoryName,
        ),
      ),
    );
    
    // Call the original callbacks if provided
    if (mode == 'practice' && onPracticeModeSelected != null) {
      onPracticeModeSelected!();
    } else if (mode == 'test' && onTestModeSelected != null) {
      onTestModeSelected!();
    }
  }
  
  Widget _buildModeCard({
    required BuildContext context,
    required IconData icon,
    required String title,
    required String description,
    required List<String> features,
    required String buttonText,
    required Color backgroundColor,
    Function()? onPressed,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16.r),
        border: Border.all(
          color: AppTheme.secondaryColor.withOpacity(0.2),
          width: 1,
        ),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.05),
            blurRadius: 10,
            offset: Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Content section
          Padding(
            padding: EdgeInsets.fromLTRB(16.r, 16.r, 16.r, 8.r),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    Container(
                      padding: EdgeInsets.all(8.w),
                      decoration: BoxDecoration(
                        color: AppTheme.secondaryColor.withOpacity(0.1),
                        borderRadius: BorderRadius.circular(8.r),
                      ),
                      child: Icon(
                        icon,
                        size: 20.sp,
                        color: AppTheme.secondaryColor,
                      ),
                    ),
                    
                    SizedBox(width: 12.w),
                    
                    Expanded(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            title,
                            style: GoogleFonts.poppins(
                              fontSize: 16.sp,
                              fontWeight: FontWeight.w600,
                              color: AppTheme.secondaryColor,
                            ),
                          ),
                          SizedBox(height: 4.h),
                          Text(
                            description,
                            style: GoogleFonts.poppins(
                              fontSize: 12.sp,
                              color: Colors.grey[600],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ],
                ),
                
                SizedBox(height: 16.h),
                
                // Features list
                Wrap(
                  spacing: 8.w,
                  runSpacing: 8.h,
                  children: features.map((feature) => Container(
                    padding: EdgeInsets.symmetric(horizontal: 8.w, vertical: 4.h),
                    decoration: BoxDecoration(
                      color: AppTheme.primaryColor.withOpacity(0.1),
                      borderRadius: BorderRadius.circular(12.r),
                    ),
                    child: Text(
                      feature,
                      style: GoogleFonts.poppins(
                        fontSize: 10.sp,
                        color: AppTheme.primaryColor,
                        fontWeight: FontWeight.w500,
                      ),
                    ),
                  )).toList(),
                ),
              ],
            ),
          ),
          
          // Button section
          Container(
            decoration: BoxDecoration(
              color: AppTheme.secondaryColor.withOpacity(0.05),
              borderRadius: BorderRadius.only(
                bottomLeft: Radius.circular(16.r),
                bottomRight: Radius.circular(16.r),
              ),
            ),
            padding: EdgeInsets.fromLTRB(16.r, 8.r, 16.r, 16.r),
            child: SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: onPressed,
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppTheme.secondaryColor,
                  foregroundColor: Colors.white,
                  padding: EdgeInsets.symmetric(vertical: 12.h),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.r),
                  ),
                  elevation: 0,
                ),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    Text(
                      buttonText,
                      style: GoogleFonts.poppins(
                        fontSize: 14.sp,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(width: 8.w),
                    Icon(
                      Icons.arrow_forward,
                      size: 16.sp,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// A custom bottom sheet that shows the mode selection with a blurred background.
class ModeSelectionBottomSheet {
  static Future<void> show({
    required BuildContext context,
    required String topicName,
    required String subcategoryName,
    String type = 'programming', // Default to programming for backward compatibility
    Map<String, dynamic>? quizParams,
    Function()? onPracticeModeSelected,
    Function()? onTestModeSelected,
    // Firebase path parameters for programming quizzes
    String? categoryId,
    String? subcategory,
    String? topic,
  }) async {
    // Determine quiz parameters based on type and context
    Map<String, dynamic> finalQuizParams = quizParams ?? {};
    
    if (finalQuizParams.isEmpty) {
      // Try to get user data for academic type
      if (type == 'academic') {
        try {
          final authProvider = Provider.of<AuthProvider>(context, listen: false);
          final userData = await authProvider.getCurrentUserData();
          
          finalQuizParams = {
            'college': userData?['college'] ?? '',
            'department': '', // This should be passed from the calling screen
            'semester': '', // This should be passed from the calling screen
            'subject': topicName,
            'unit': subcategoryName,
          };
        } catch (e) {
          print('Error getting user data for academic quiz: $e');
        }
      } else {
        // Programming type default params
        finalQuizParams = {
          'mainTopic': 'Programming',
          'programmingLanguage': topicName,
          'subTopic': subcategoryName,
          // Firebase path parameters for fetching prompt templates
          if (categoryId != null) 'categoryId': categoryId,
          if (subcategory != null) 'subcategory': subcategory, 
          if (topic != null) 'topic': topic,
        };
      }
    }
    
    // Ensure Firebase path parameters are included for programming quizzes
    if (type == 'programming') {
      finalQuizParams['categoryId'] = categoryId ?? finalQuizParams['categoryId'];
      finalQuizParams['subcategory'] = subcategory ?? finalQuizParams['subcategory'];
      finalQuizParams['topic'] = topic ?? finalQuizParams['topic'];
      
      // Debug log to verify parameters
      print('ModeSelection: Firebase path params - categoryId: $categoryId, subcategory: $subcategory, topic: $topic');
    }
    
    return showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      backgroundColor: Colors.transparent,
      barrierColor: Colors.black.withOpacity(0.5),
      builder: (context) {
        return Stack(
          alignment: Alignment.bottomCenter,
          children: [
            // Positioned blurred background behind the card
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              height: 450.h, // Increased height for more features
              child: ClipRRect(
                borderRadius: BorderRadius.only(
                  topLeft: Radius.circular(48),
                  topRight: Radius.circular(48),
                ),
                child: BackdropFilter(
                  filter: ImageFilter.blur(sigmaX: 15, sigmaY: 15),
                  child: Container(
                    color: Colors.transparent,
                  ),
                ),
              ),
            ),
            
            // The mode selection card
            Positioned(
              bottom: 0,
              left: 0,
              right: 0,
              child: ModeSelectionCard(
                topicName: topicName,
                subcategoryName: subcategoryName,
                type: type,
                quizParams: finalQuizParams,
                onPracticeModeSelected: onPracticeModeSelected,
                onTestModeSelected: onTestModeSelected,
              ),
            ),
          ],
        );
      },
    );
  }
}