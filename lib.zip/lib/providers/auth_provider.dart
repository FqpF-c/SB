import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:intl/intl.dart';

class AuthProvider with ChangeNotifier {
  final FirebaseAuth _auth = FirebaseAuth.instance;
  final FirebaseFirestore _firestore = FirebaseFirestore.instance;
  
  User? get currentUser => _auth.currentUser;
  Stream<User?> get authStateChanges => _auth.authStateChanges();
  
  // Check if a user with the given phone number exists
  Future<bool> checkIfUserExists(String phoneNumber) async {
    try {
      final querySnapshot = await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .where('phone_number', isEqualTo: phoneNumber)
          .limit(1)
          .get();
      
      bool exists = querySnapshot.docs.isNotEmpty;
      print('CRITICAL: User exists check for $phoneNumber: $exists');
      return exists;
    } catch (e) {
      print('Error checking user existence: $e');
      return false;
    }
  }
  
  // Check if the current authenticated user exists in Firestore
  Future<bool> doesCurrentUserExistInFirestore() async {
    try {
      final user = _auth.currentUser;
      if (user == null) return false;
      
      final docSnapshot = await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .get();
      
      return docSnapshot.exists;
    } catch (e) {
      print('Error checking current user existence: $e');
      return false;
    }
  }
  
  // Check if user is logged in
  Future<bool> isUserLoggedIn() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final isLoggedIn = prefs.getBool('is_logged_in') ?? false;
      final storedPhoneNumber = prefs.getString('phone_number');
      
      print('CRITICAL: Checking login status - isLoggedIn: $isLoggedIn, phone: $storedPhoneNumber');
      
      // For the new OTP system, we primarily rely on SharedPreferences
      // but still maintain Firebase Auth for data consistency
      if (isLoggedIn && storedPhoneNumber != null) {
        final currentUser = _auth.currentUser;
        
        if (currentUser != null) {
          // Check if user exists in Firestore
          final exists = await doesCurrentUserExistInFirestore();
          if (!exists) {
            // If user doesn't exist in Firestore, consider them not logged in
            await prefs.setBool('is_logged_in', false);
            await prefs.remove('phone_number');
            return false;
          }
        } else {
          // No Firebase user but SharedPreferences says logged in
          // For OTP system, we still need a Firebase user for Firestore operations
          print('CRITICAL: No Firebase user found, but SharedPreferences indicates logged in');
          
          // Try to create an anonymous user for Firestore operations
          try {
            await _auth.signInAnonymously();
            print('CRITICAL: Created anonymous Firebase user for data operations');
          } catch (e) {
            print('CRITICAL ERROR: Failed to create anonymous user: $e');
            // If we can't create a Firebase user, consider them not logged in
            await prefs.setBool('is_logged_in', false);
            await prefs.remove('phone_number');
            return false;
          }
        }
        
        return true;
      }
      
      return false;
    } catch (e) {
      print('Error checking if user is logged in: $e');
      return false;
    }
  }
  
  // Set user as logged in
  Future<void> setLoggedIn(String phoneNumber) async {
    try {
      print('CRITICAL: Setting user as logged in for phone: $phoneNumber');
      
      // Ensure Firebase Auth has an active user (create anonymous if needed)
      User? user = _auth.currentUser;
      if (user == null) {
        try {
          final userCredential = await _auth.signInAnonymously();
          user = userCredential.user;
          print('CRITICAL: Created anonymous Firebase user: ${user?.uid}');
        } catch (e) {
          print('CRITICAL ERROR: Failed to create Firebase user: $e');
          throw Exception('Failed to create user session. Please try again.');
        }
      }
      
      if (user == null) {
        throw Exception('No authenticated user found. Please try again.');
      }
      
      // Update SharedPreferences
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_logged_in', true);
      await prefs.setString('phone_number', phoneNumber);
      
      print('CRITICAL: SharedPreferences updated successfully');
      
      // Check if user already exists in Firestore
      final exists = await checkIfUserExists(phoneNumber);
      
      if (exists) {
        print('CRITICAL: Existing user found, updating last login');
        // Update last login timestamp for existing user
        final querySnapshot = await _firestore
            .collection('skillbench')
            .doc('ALL_USERS')
            .collection('users')
            .where('phone_number', isEqualTo: phoneNumber)
            .limit(1)
            .get();
        
        if (querySnapshot.docs.isNotEmpty) {
          final userDoc = querySnapshot.docs.first;
          await userDoc.reference.update({
            'last_login': Timestamp.now(),
            'uid': user.uid, // Update UID in case it changed
          });
          print('CRITICAL: Updated existing user last login');
        }
      } else {
        print('CRITICAL: New user detected, will need registration');
      }
      
      notifyListeners();
    } catch (e) {
      print('Error setting user as logged in: $e');
      throw e;
    }
  }
  
  // Register a new user
  Future<void> registerUser(Map<String, dynamic> userData) async {
    try {
      User? user = _auth.currentUser;
      if (user == null) {
        // Try to create anonymous user if none exists
        try {
          final userCredential = await _auth.signInAnonymously();
          user = userCredential.user;
          print('CRITICAL: Created anonymous user for registration: ${user?.uid}');
        } catch (e) {
          throw Exception('User session not found. Please try login again.');
        }
      }
      
      if (user == null) {
        throw Exception('User not authenticated');
      }
      
      final uid = user.uid;
      final phoneNumber = userData['phone_number'];
      final college = userData['college'];
      final department = userData['department'];
      final batch = userData['batch'];
      
      print('CRITICAL: Registering user with UID: $uid, Phone: $phoneNumber');
      
      // Transaction to ensure atomicity of operations
      await _firestore.runTransaction((transaction) async {
        // 1. Create/update user in ALL_USERS collection
        final mainUserRef = _firestore
            .collection('skillbench')
            .doc('ALL_USERS')
            .collection('users')
            .doc(uid);
            
        final userSnapshot = await transaction.get(mainUserRef);
        
        // Prepare complete user data with additional fields
        final completeUserData = {
          ...userData,
          'uid': uid,
          'created_at': Timestamp.now(),
          'last_login': Timestamp.now(),
          'streaks': userData['streaks'] ?? 0,
          'coins': userData['coins'] ?? 5,
          'xp': userData['xp'] ?? 20,
          'daily_usage': userData['daily_usage'] ?? 0,
          'total_usage': userData['total_usage'] ?? 0,
          'gender': userData['gender'] ?? 'prefer_not_to_say',
          'total_request': userData['total_request'] ?? {
            'practice_mode': 0,
            'test_mode': 0,
          },
        };
        
        if (userSnapshot.exists) {
          // User already exists, just update
          print('CRITICAL: Updating existing user in Firestore');
          transaction.update(mainUserRef, {
            ...completeUserData,
            'last_login': Timestamp.now(),
          });
        } else {
          // Create new user
          print('CRITICAL: Creating new user in Firestore');
          transaction.set(mainUserRef, completeUserData);
        }
        
        // 2. Create reference in college > department > batch > users collection
        final collegeUserRef = _firestore
            .collection('skillbench')
            .doc(college)
            .collection(department)
            .doc(batch)
            .collection('users')
            .doc(uid);
            
        // Set a reference to the main user document
        transaction.set(collegeUserRef, {
          'uid': uid,
          'username': userData['username'],
          'phone_number': phoneNumber,
          'reference': mainUserRef,  // Store reference to main user document
        });
        
        print('CRITICAL: Created user reference in college collection');
      });
      
      // Set login status (this should already be set, but ensure consistency)
      await setLoggedIn(phoneNumber);
      
      print('CRITICAL: User registration completed successfully');
      
    } catch (e) {
      print('Error registering user: $e');
      throw e;
    }
  }
  
  // Sign out the user
  Future<void> signOut() async {
    try {
      print('CRITICAL: Starting sign out process');
      
      // Update SharedPreferences first (in case Firebase Auth fails)
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool('is_logged_in', false);
      await prefs.remove('phone_number');
      
      print('CRITICAL: Cleared SharedPreferences');
      
      // Then sign out from Firebase
      await _auth.signOut();
      
      print('CRITICAL: Firebase sign out completed');
      
      notifyListeners();
    } catch (e) {
      print('Error signing out: $e');
      throw e;
    }
  }
  
  // Get current user data from Firestore
  Future<Map<String, dynamic>?> getCurrentUserData() async {
    try {
      final user = _auth.currentUser;
      if (user == null) {
        print('CRITICAL: No current user found for getting user data');
        return null;
      }
      
      final docSnapshot = await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .get();
      
      if (docSnapshot.exists) {
        print('CRITICAL: Retrieved user data successfully');
        return docSnapshot.data();
      }
      
      print('CRITICAL: No user data found in Firestore');
      return null;
    } catch (e) {
      print('Error getting user data: $e');
      return null;
    }
  }
  
  // Update user streaks, coins, and XP
  Future<void> updateUserStats({
    int? streaks,
    int? coins,
    int? xp,
  }) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      final updateData = <String, dynamic>{};
      if (streaks != null) updateData['streaks'] = streaks;
      if (coins != null) updateData['coins'] = coins;
      if (xp != null) updateData['xp'] = xp;
      
      if (updateData.isEmpty) return;
      
      // Update in Firestore
      await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .update(updateData);
      
      notifyListeners();
    } catch (e) {
      print('Error updating user stats: $e');
      throw e;
    }
  }
  
  // Update daily usage time
  Future<void> updateDailyUsage(int minutes) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      final today = DateFormat('yyyy-MM-dd').format(DateTime.now());
      
      // Get current daily usage
      final docSnapshot = await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .get();
      
      int currentUsage = 0;
      int totalUsage = 0;
      
      if (docSnapshot.exists) {
        final data = docSnapshot.data();
        if (data != null) {
          if (data.containsKey('daily_usage')) {
            currentUsage = data['daily_usage'] as int;
          }
          if (data.containsKey('total_usage')) {
            totalUsage = data['total_usage'] as int;
          }
        }
      }
      
      // Update the usage
      final newDailyUsage = currentUsage + minutes;
      final newTotalUsage = totalUsage + minutes;
      
      // Update in Firestore
      await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .update({
            'daily_usage': newDailyUsage,
            'total_usage': newTotalUsage,
            'last_usage_date': today,
          });
      
      notifyListeners();
    } catch (e) {
      print('Error updating daily usage: $e');
      throw e;
    }
  }
  
  // Update total requests
  Future<void> updateTotalRequests(String mode) async {
    try {
      final user = _auth.currentUser;
      if (user == null) throw Exception('User not authenticated');
      
      // Get current request counts
      final docSnapshot = await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .get();
      
      if (!docSnapshot.exists) return;
      
      final data = docSnapshot.data();
      if (data == null || !data.containsKey('total_request')) return;
      
      final totalRequest = data['total_request'] as Map<String, dynamic>;
      int practiceMode = totalRequest['practice_mode'] as int? ?? 0;
      int testMode = totalRequest['test_mode'] as int? ?? 0;
      
      if (mode == 'practice_mode') {
        practiceMode++;
      } else if (mode == 'test_mode') {
        testMode++;
      }
      
      // Update in Firestore
      await _firestore
          .collection('skillbench')
          .doc('ALL_USERS')
          .collection('users')
          .doc(user.uid)
          .update({
            'total_request': {
              'practice_mode': practiceMode,
              'test_mode': testMode,
            },
          });
      
      notifyListeners();
    } catch (e) {
      print('Error updating total requests: $e');
      throw e;
    }
  }
}