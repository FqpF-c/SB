import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart' as firebase_auth;
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'dart:math' show pi, cos, sin;
import 'package:flutter/services.dart';

import '../../providers/auth_provider.dart';
import '../../theme/default_theme.dart';
import '../../widgets/home/ongoing_programs_widget.dart';
import '../../widgets/home/technologies_widget.dart';
import '../../widgets/home/programming_languages_widget.dart';
import '../../widgets/home/stats_row_widget.dart';

// Custom painter for curved pattern in header (from prep.dart)
class HeaderPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final Paint paint = Paint()
      ..color = Color.fromRGBO(168, 130, 201, 0.452) // Changed to rgb(100, 68, 128) with 0.3 opacity
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    
    // Draw concentric circles
    // Moved circles more to the right and increased their size
    final centerX = size.width * 1.1;  // Moved from 0.8 to 0.9 (more to the right)
    final centerY = size.height * 0.2;
    
    // Increased the number of circles and their size
    for (int i = 1; i <= 7; i++) {  // Increased from 6 to 8 circles
      canvas.drawCircle(
        Offset(centerX, centerY),
        23.0 * i,  // Increased size from 20.0 to 25.0
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}

// Circle pattern painter from prep.dart
class CirclePatternPainter extends CustomPainter {
  final Color color;
  
  CirclePatternPainter({
    this.color = const Color.fromRGBO(100, 68, 128, 1), // Changed from white to rgb(100, 68, 128)
  });
  
  @override
  void paint(Canvas canvas, Size size) {
    // All circles positioned exactly at the top right corner (size.width, 0)
    final topRight = Offset(size.width, 0);
    
    // Largest outer circle - increased size
    final paint1 = Paint()
      ..color = color.withOpacity(0.15) // Increased opacity
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
      topRight, // Top right corner
      size.width * 0.9, // Increased from 0.7 to 0.9
      paint1,
    );
    
    // Medium circle - increased size
    final paint2 = Paint()
      ..color = color.withOpacity(0.20) // Increased opacity
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
      topRight, // Top right corner
      size.width * 0.7, // Increased from 0.5 to 0.7
      paint2,
    );
    
    // Smaller circle - increased size
    final paint3 = Paint()
      ..color = color.withOpacity(0.25) // Increased opacity
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
      topRight, // Top right corner
      size.width * 0.5, // Increased from 0.35 to 0.5
      paint3,
    );
    
    // Smallest inner circle - increased size
    final paint4 = Paint()
      ..color = color.withOpacity(0.30) // Increased opacity
      ..style = PaintingStyle.fill;
    canvas.drawCircle(
      topRight, // Top right corner
      size.width * 0.3, // Increased from 0.2 to 0.3
      paint4,
    );
  }
  
  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

// Pentagon clipper from prep.dart
class PentagonClipper extends CustomClipper<Path> {
  @override
  Path getClip(Size size) {
    final path = Path();
    final centerX = size.width / 2;
    final centerY = size.height / 2;
    final radius = size.width / 2;

    path.moveTo(centerX, 0);
    for (int i = 1; i <= 5; i++) {
      final angle = (i * 2 * pi / 5) - (pi / 2);
      final x = centerX + radius * cos(angle);
      final y = centerY + radius * sin(angle);
      path.lineTo(x, y);
    }

    path.close();
    return path;
  }

  @override
  bool shouldReclip(CustomClipper<Path> oldClipper) => false;
}

class HomeScreen extends StatefulWidget {
  const HomeScreen({Key? key}) : super(key: key);

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with TickerProviderStateMixin {
  // User data
  String _username = '';
  int _coins = 0;
  int _streaks = 0;
  int _xp = 0;
  int _rankPosition = 24;
  int _completed = 2;
  int _studyHours = 128;
  bool _isLoading = true;
  
  // Firebase data
  List<String> _categoryTitles = [];
  Map<String, List<Map<String, dynamic>>> _categoryItems = {};
  
  // Animation controllers for UI elements (from prep.dart)
  late List<AnimationController> _shapeControllers;
  late List<Animation<double>> _shapeAnimations;
  
  @override
  void initState() {
    super.initState();
    _loadUserData();
    _loadCategoryTitles();
    
    // Initialize shape animations (from prep.dart)
    _shapeControllers = List.generate(12, (index) {
      return AnimationController(
        duration: Duration(milliseconds: 2000 + (index * 300)),
        vsync: this,
      )..repeat(reverse: true);
    });

    _shapeAnimations = _shapeControllers.map((controller) {
      return Tween<double>(begin: -10, end: 10).animate(
        CurvedAnimation(
          parent: controller,
          curve: Curves.easeInOut,
        ),
      );
    }).toList();
  }
  
  @override
  void dispose() {
    // Dispose animation controllers (from prep.dart)
    for (var controller in _shapeControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) {
      return 'GOOD MORNING';
    } else if (hour < 17) {
      return 'GOOD AFTERNOON';
    } else {
      return 'GOOD EVENING';
    }
  }

  Future<void> _loadUserData() async {
    setState(() {
      _isLoading = true;
    });

    try {
      // Get current auth user
      final authProvider = Provider.of<AuthProvider>(context, listen: false);
      final user = firebase_auth.FirebaseAuth.instance.currentUser;

      if (user == null) {
        throw Exception('User not authenticated');
      }

      // Fetch user data from Firestore
      final firestoreData = await authProvider.getCurrentUserData();
      
      if (firestoreData != null) {
        // Get user name from Firestore
        final username = firestoreData['username'] ?? 'User';
        
        // Fetch real-time data from Firebase Realtime Database
        final databaseRef = FirebaseDatabase.instance.ref().child('skillbench/users/${user.uid}');
        final dataSnapshot = await databaseRef.get();
        
        if (dataSnapshot.exists) {
          final data = dataSnapshot.value as Map<dynamic, dynamic>;
          
          // Update state with the fetched data
          if (mounted) {
            setState(() {
              _username = username;
              _coins = data['coins'] ?? 0;
              _streaks = data['streaks'] ?? 0;
              _xp = data['xp'] ?? 0;
              _isLoading = false;
            });
          }
        } else {
          // If realtime database doesn't have data, use Firestore data as fallback
          if (mounted) {
            setState(() {
              _username = username;
              _coins = firestoreData['coins'] ?? 0;
              _streaks = firestoreData['streaks'] ?? 0;
              _xp = firestoreData['xp'] ?? 0;
              _isLoading = false;
            });
          }
        }
      }
    } catch (e) {
      print('Error loading user data: $e');
      if (mounted) {
        setState(() {
          _isLoading = false;
        });
      }
    }
  }

  // Load category titles from Firebase
  Future<void> _loadCategoryTitles() async {
    try {
      final titlesRef = FirebaseFirestore.instance.doc('/prep/Title');
      final docSnapshot = await titlesRef.get();
      
      if (docSnapshot.exists && docSnapshot.data() != null) {
        final data = docSnapshot.data()!;
        if (data.containsKey('Title') && data['Title'] is List) {
          final List<String> titles = List<String>.from(data['Title']);
          
          if (mounted) {
            setState(() {
              _categoryTitles = titles;
            });
          }
          
          // Debug
          print('Loaded category titles: $_categoryTitles');
          
          // Load items for each category except Programming Language
          for (final title in titles) {
            if (title != 'Programming Language') {
              await _loadCategoryItems(title);
            }
          }
        }
      }
    } catch (e) {
      print('Error loading category titles: $e');
    }
  }
  
  // Fetch items for a specific category
  Future<void> _loadCategoryItems(String category) async {
    try {
      print('Loading items for category: $category');
      final categoryItemsRef = FirebaseFirestore.instance.doc('/prep/Title/$category/$category');
      final docSnapshot = await categoryItemsRef.get();
      
      if (docSnapshot.exists && docSnapshot.data() != null) {
        final data = docSnapshot.data()!;
        
        // Debug the document data
        print('Category document data: $data');
        
        // Check for the field with same name as category
        if (data.containsKey(category) && data[category] is List) {
          final List<dynamic> rawItems = data[category];
          print('Raw items for $category: $rawItems');
          
          // Convert items to Map<String, dynamic> with defaults for missing fields
          final List<Map<String, dynamic>> formattedItems = [];
          
          for (var item in rawItems) {
            if (item is Map) {
              final Map<String, dynamic> formattedItem = Map<String, dynamic>.from(item as Map);
              
              // Set default values for icon and color if not present
              if (!formattedItem.containsKey('icon')) {
                formattedItem['icon'] = category == 'Programming Language' 
                    ? 'assets/icons/code_icon.png' 
                    : Icons.code;
              }
              
              if (!formattedItem.containsKey('color')) {
                formattedItem['color'] = const Color(0xFF366D9C);
              }
              
              formattedItems.add(formattedItem);
            } else if (item is String) {
              // If item is just a string, create a map with defaults
              formattedItems.add({
                'name': item,
                'icon': category == 'Programming Language' 
                    ? 'assets/icons/code_icon.png' 
                    : Icons.code,
                'color': const Color(0xFF366D9C)
              });
            }
          }
          
          print('Formatted items for $category: $formattedItems');
          
          if (mounted) {
            setState(() {
              _categoryItems[category] = formattedItems;
            });
          }
        }
      }
    } catch (e) {
      print('Error loading items for $category: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    // Set status bar color to match the purple header
    SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
      statusBarColor: Colors.transparent,
      statusBarIconBrightness: Brightness.light,
    ));
    
    return Scaffold(
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: () async {
                await _loadUserData();
                await _loadCategoryTitles();
              },
              color: Color(0xFF341B58),
              backgroundColor: Colors.white,
              child: CustomScrollView(
                physics: const AlwaysScrollableScrollPhysics(),
                slivers: [
                  // Welcome header with curved background
                  SliverToBoxAdapter(
                    child: _buildWelcomeHeader(),
                  ),
                  
                  // Stats box
                  SliverToBoxAdapter(
                    child: _buildStatsBox(),
                  ),
                  
                  // Main content
                  SliverToBoxAdapter(
                    child: Transform.translate(
                      offset: const Offset(0, -40),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          // Ongoing Programs Section
                          OngoingProgramsWidget(
                            categoryItems: _categoryItems,
                          ),
                          
                          // Technologies Section
                          TechnologiesWidget(
                            categoryItems: _categoryItems,
                            categoryTitles: _categoryTitles,
                          ),
                          
                          // Programming Languages Section
                          const ProgrammingLanguagesWidget(),
                          
                          SizedBox(height: 80.h), // Bottom space for the navigation bar
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
    );
  }

  Widget _buildWelcomeHeader() {
    final screenWidth = MediaQuery.of(context).size.width;
    final bool isSmallScreen = screenWidth < 360;
    
    return Stack(
      clipBehavior: Clip.none,
      children: [
        // Main container with the curved bottom - with increased height
        Container(
          width: double.infinity,
          height: isSmallScreen ? 225 : 250,
          decoration: BoxDecoration(
            color: Color(0xFF341B58),
            borderRadius: BorderRadius.only(
              bottomLeft: Radius.circular(60),
              bottomRight: Radius.circular(60),
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.1),
                blurRadius: 10,
                offset: Offset(0, 5),
              ),
            ],
          ),
          child: SafeArea(
            bottom: false,
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                isSmallScreen ? 20 : 40,
                20,
                20, 
                20
              ),
              child: Column(
                mainAxisSize: MainAxisSize.max,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Spacer(flex: 1),
                  
                  // Good Morning with Sun icon
                  Row(
                    children: [
                      Icon(
                        Icons.wb_sunny_outlined,
                        color: Color.fromRGBO(255, 214, 221, 1),
                        size: isSmallScreen ? 15 : 17,
                      ),
                      const SizedBox(width: 6),
                      Text(
                        _getGreeting(),
                        style: TextStyle(
                          color: Color.fromRGBO(255, 214, 221, 1),
                          fontSize: isSmallScreen ? 12 : 14,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  
                  // Greeting with username
                  Row(
                    children: [
                      Text(
                        "Hi, ",
                        style: TextStyle(
                          color: Color.fromRGBO(223, 103, 140, 1),
                          fontSize: isSmallScreen ? 24 : 28,
                          fontWeight: FontWeight.w500,
                        ),
                      ),
                      Flexible(
                        child: Text(
                          _username,
                          style: TextStyle(
                            color: Colors.white,
                            fontSize: isSmallScreen ? 24 : 28,
                            fontWeight: FontWeight.normal,
                          ),
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 4),
                  
                  // Underline bar
                  Container(
                    margin: EdgeInsets.only(top: 5.h, bottom: 25.h),
                    width: 75.w,
                    height: 3.h,
                    decoration: BoxDecoration(
                      color: const Color(0xFFE57896),
                      borderRadius: BorderRadius.circular(2.r),
                    ),
                  ),
                  
                  const Spacer(flex: 1),
                  
                  // Stats row
                  _buildWelcomeHeaderStatsRow(),
                  
                  // Extra space at the bottom to extend downward
                  SizedBox(height: isSmallScreen ? 5 : 10),
                ],
              ),
            ),
          ),
        ),
        
        // Curved pattern overlay in top-right
        Positioned(
          top: -60,
          right: 20,
          child: SizedBox(
            width: MediaQuery.of(context).size.width * 0.5,
            height: 280,
            child: CustomPaint(
              painter: HeaderPatternPainter(),
            ),
          ),
        ),
      ],
    );
  }

  Widget _buildWelcomeHeaderStatsRow() {
    final screenWidth = MediaQuery.of(context).size.width;
    
    // Dynamically adjust spacing based on screen width
    final double rowSpacing = screenWidth < 360 ? 15 : screenWidth < 400 ? 20 : 30;
    final double containerHeight = screenWidth < 360 ? 40 : 50;

    // Use Transform.translate instead of negative margin
    return Transform.translate(
      offset: Offset(screenWidth < 360 ? -10 : -3, 0), // Shift left by 10px on small screens, 3px on larger
      child: Container(
        height: containerHeight,
        margin: EdgeInsets.zero, // No margin - using Transform instead
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Row(
            mainAxisSize: MainAxisSize.min,
            children: [
              _buildStatPill(Icons.local_fire_department, _streaks.toString(), null),
              SizedBox(width: rowSpacing),
              _buildStatPill(Icons.currency_rupee, _coins.toString(), null),
              SizedBox(width: rowSpacing),
              _buildStatPill(Icons.emoji_events, _xp.toString(), null),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildStatPill(IconData icon, String value, String? suffix) {
    // Map icons to their respective image assets
    String getImageAsset() {
      if (icon == Icons.local_fire_department) {
        return 'assets/icons/streak_icon.png'; // Streak icon
      } else if (icon == Icons.currency_rupee) {
        return 'assets/icons/coin_icon.png'; // Coin icon
      } else if (icon == Icons.emoji_events) {
        return 'assets/icons/xp_icon.png'; // XP icon
      }
      return 'assets/icons/streak_icon.png'; // Fallback
    }

    // Scale factors based on screen width
    final screenWidth = MediaQuery.of(context).size.width;
    final scale = screenWidth < 360 ? 0.8 : 1.0; // Scale down on smaller screens
    
    // Dynamically adjust spacing for smaller screens
    final double horizontalPadding = screenWidth < 360 ? 1 : 2;
    final double rightPadding = screenWidth < 360 ? 12 : 23;
    final double iconTextSpacing = screenWidth < 360 ? 6 : 12;
    final double iconSize = scale * 40;
    final double fontSize = scale * 16;

    return Container(
      padding: EdgeInsets.only(
        left: horizontalPadding, 
        right: rightPadding, 
        top: 1, 
        bottom: 1
      ),
      decoration: BoxDecoration(
        border: Border.all(
          color: const Color.fromRGBO(95, 38, 105, 1),
          width: 1.5,
        ),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min, // Important for preventing overflow
        children: [
          Image.asset(
            getImageAsset(),
            width: iconSize,
            height: iconSize,
            fit: BoxFit.contain,
            errorBuilder: (context, error, stackTrace) {
              // Fallback to icon if image is not available
              return Icon(
                icon,
                color: Colors.white,
                size: iconSize * 0.6,
              );
            },
          ),
          SizedBox(width: iconTextSpacing),
          Text(
            value,
            style: TextStyle(
              color: Colors.white,
              fontWeight: FontWeight.bold,
              fontSize: fontSize,
            ),
          ),
          if (suffix != null) ...[
            const SizedBox(width: 4),
            Text(
              suffix,
              style: TextStyle(
                color: Colors.white,
                fontWeight: FontWeight.bold,
                fontSize: fontSize,
              ),
            ),
          ],
        ],
      ),
    );
  }

  Widget _buildStatsBox() {
    return Transform.translate(
      offset: const Offset(0, -65), // Keep the same upward overlap
      child: Container(
        width: double.infinity,
        // Decreased bottom padding from 25 to 15
        padding: const EdgeInsets.fromLTRB(20, 65, 20, 15),
        decoration: BoxDecoration(
          gradient: const LinearGradient(
            colors: [Color(0xFFE17DA8), Color(0xFFE15E89)],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
          borderRadius: const BorderRadius.only(
            bottomLeft: Radius.circular(48),
            bottomRight: Radius.circular(48),
          ),
        ),
        child: Column(
          children: [
            // Decreased top padding from 15 to 10
            SizedBox(height: 15),
            
            // Stats row
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildStatItem(
                  icon: Icons.check_circle_outline,
                  label: "Completed",
                  value: _completed.toString(),
                ),
                Container(height: 40, width: 1, color: Colors.white.withOpacity(0.3)),
                _buildStatItem(
                  icon: Icons.leaderboard,
                  label: "Rank Position",
                  value: _rankPosition.toString(),
                ),
                Container(height: 40, width: 1, color: Colors.white.withOpacity(0.3)),
                _buildStatItem(
                  icon: Icons.access_time,
                  label: "Study Hours",
                  value: _studyHours.toString(),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  // Build individual stat item for the stats box
  Widget _buildStatItem({
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Icon(
          icon,
          color: Colors.white,
          size: 22,
        ),
        const SizedBox(height: 6),
        Text(
          label,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 12,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            color: Colors.white,
            fontSize: 20,
            fontWeight: FontWeight.bold,
          ),
        ),
      ],
    );
  }

  Widget _buildSectionHeader(String title) {
    // Determine if this is the Programming Language section
    bool isProgrammingLanguageSection = title == 'Programming Language' || 
                                        title == 'Programming Languages';
    
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 16),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            title,
            style: const TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.bold,
              color: Colors.black87,
            ),
          ),
          isProgrammingLanguageSection ? Text(
            "View all",
            style: TextStyle(
              fontSize: 14,
              color: Color.fromRGBO(237, 85, 100, 1),
              fontWeight: FontWeight.w500,
            ),
          ) : SizedBox(),
        ],
      ),
    );
  }
}