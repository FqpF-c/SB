import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_screenutil/flutter_screenutil.dart';

import '../screens/home/home_screen.dart';
import '../screens/academics/academics_screen.dart';
import '../screens/lead/lead_screen.dart';
import '../screens/test/test_screen.dart';
import '../screens/profile/profile_screen.dart';

class NavBar extends StatefulWidget {
  const NavBar({Key? key}) : super(key: key);

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int _currentIndex = 0;
  
  final List<Widget> _screens = [
    const HomeScreen(),
    const AcademicsScreen(),
    const LeadScreen(),
    const TestScreen(),
    const ProfileScreen(),
  ];
  
  final List<String> _titles = [
    'Home',
    'Academics',
    'Lead',
    'Test',
    'Profile',
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.grey.withOpacity(0.2),
              blurRadius: 10,
              offset: const Offset(0, -5),
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: _currentIndex,
          onTap: (index) {
            setState(() {
              _currentIndex = index;
            });
          },
          type: BottomNavigationBarType.fixed,
          backgroundColor: Colors.white,
          selectedItemColor: const Color(0xFF3D1560),
          unselectedItemColor: Colors.grey.shade500,
          selectedLabelStyle: GoogleFonts.roboto(
            fontSize: 12.sp,
            fontWeight: FontWeight.w500,
          ),
          unselectedLabelStyle: GoogleFonts.roboto(
            fontSize: 12.sp,
            fontWeight: FontWeight.w400,
          ),
          items: [
            BottomNavigationBarItem(
              icon: Icon(Icons.home_outlined, size: 24.sp),
              activeIcon: Icon(Icons.home, size: 24.sp),
              label: 'Home',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.school_outlined, size: 24.sp),
              activeIcon: Icon(Icons.school, size: 24.sp),
              label: 'Academics',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.leaderboard_outlined, size: 24.sp),
              activeIcon: Icon(Icons.leaderboard, size: 24.sp),
              label: 'Lead',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.quiz_outlined, size: 24.sp),
              activeIcon: Icon(Icons.quiz, size: 24.sp),
              label: 'Test',
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline, size: 24.sp),
              activeIcon: Icon(Icons.person, size: 24.sp),
              label: 'Profile',
            ),
          ],
        ),
      ),
    );
  }
}